// 定义一个混合对象
var myMixin = {
  created: function () {
    this.hello()
  },
  methods: {
    hello: function () {
      alert('hello from mixin!')
    }
  }
}

// 定义一个组件，使用这个混合对象
var Component = Vue.extend({
  mixins: [myMixin],
  template:'<div>this is a mixin component</div>'
});


new Vue({
  el: '#app',
  components:{
      myComponent:Component
  }
})
