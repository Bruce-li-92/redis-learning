
var vm = new Vue({
    el: '#app',
    data: {
        msg:'this is a message',
        number:1,
        disabled:true,
        url:'http://www.baidu.com',
        isAClass:true,
        activeColor:'red'
    },
    methods:{
        showAlert:function(){
            alert('showAlert');
        }
    }
});
