var vm = new Vue({
  el: '#app',
  data: {
    firstName: 'Foo',
    lastName: 'Bar',
    isShowFirstName: true,
    isShowLastName: true,
    items:[
        {message:1},
        {message:2},
        {message:3},
        {message:4},
        {message:5}
    ],
    object: {
      FirstName: 'John',
      LastName: 'Doe',
      Age: 30
    }
  }
})
