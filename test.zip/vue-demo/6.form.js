var vm = new Vue({
    el: '#app',
    data: {
        checkedNames: [],
        selected: 'A',
        options: [{
            text: 'One',
            value: 'A'
        }, {
            text: 'Two',
            value: 'B'
        }, {
            text: 'Three',
            value: 'C'
        }]
    }
})
