var MyComponent = Vue.extend({
    template: '<div>A custom component!</div>'
})
Vue.component('my-component', MyComponent);

var childComponent = Vue.extend({
    template: '<div>A child component!</div>'
});

var parentComponent = Vue.extend({
    template: '<div>A parent component!</div><child-component/>',
    components:{
        'child-component':childComponent
    }
});

Vue.component('parent-component', parentComponent);


var propComponent = Vue.extend({
    props:['msg','dynamicMsg'],
    template:'<div>A prop component : message is {{msg}},dynamicMsg is {{dynamicMsg}}</div>'
});
Vue.component('prop-component', propComponent);


var validComponent = Vue.extend({
    props:{
        msg:String
    },
    template:'<div>A valid component : message is {{msg}}</div>'
});
Vue.component('valid-component', validComponent);

var slotComponent = Vue.extend({
    template:'<div>A slot component <slot>如果没有分发内容则显示我。</slot> </div>'
});
Vue.component('slot-component', slotComponent);


var home1Component = Vue.extend({
    template:'<div>home1</div>'
});
var home2Component = Vue.extend({
    template:'<div>home2</div>'
});

new Vue({
  el: '#app',
  data:{
      newMsg:'hello Vue',
      currentView:'home'
  }
  ,
  methods:{
      changeView:function(){
          this.currentView = this.currentView =='home'?'home2':'home';
      }
  },
  components:{
      home:home1Component,
      home2:home2Component
  }
})
