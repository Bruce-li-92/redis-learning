Vue.filter('reverse', function (value) {
  return value.split('').reverse().join('')
})
Vue.filter('wrap', function (value, begin, end) {
  return begin + value + end
})
Vue.filter('concat', function (value, input,userInput) {
  return value + input + userInput;
})
var vm = new Vue({
    el: '#app',
    data: {
        message:'abc'
    }
})
