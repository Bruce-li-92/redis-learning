Vue.directive('my-directive', {
    bind: function() {
        // 准备工作
        // 例如，添加事件处理器或只需要运行一次的高耗任务
    },
    update: function(newValue, oldValue) {
        console.log(this);
        console.log(oldValue); //old value
        console.log(newValue); //new value
        // 值更新时的工作
        // 也会以初始值为参数调用一次
    },
    unbind: function() {
        // 清理工作
        // 例如，删除 bind() 添加的事件监听器
    }
});
Vue.directive('my-directive2', function(value) {
    alert('my-directive2:' + value);
});
Vue.elementDirective('my-directive3', {
    params: ['a','b'],
    bind: function() {
        alert('loaded directive3');
        alert(this.params.a);
        alert(this.params.b);
    }
});
var vm = new Vue({
    el: '#app',
    data: {
        someValue: 123
    }
});
